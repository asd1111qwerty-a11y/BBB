var fs   = require("fs");
var util = require('util');
var EOL  = require('os').EOL;

function Log() {
    // Nothing
}

module.exports = Log;

Log.prototype.setup = function(gameServer) {
   /* if (!fs.existsSync('./logs')) {
        // Make log folder
        fs.mkdir('./logs');
    }
    switch (gameServer.config.serverLogLevel) {
        case 2:
            ip_log = fs.createWriteStream('./logs/ip.log', {flags : 'w'});

            // Override
            this.onConnect = function(ip) {
                ip_log.write("["+this.formatTime()+"] Connect: " + ip + EOL);
            };

            this.onDisconnect = function(ip) {
                ip_log.write("["+this.formatTime()+"] Disconnect: " + ip + EOL);
            };
        case 1:
            console_log = fs.createWriteStream('./logs/console.log', {flags : 'w'});
            var LastMsg;

            console.log = function(d) {
                if ( d === LastMsg ) return;
                else 
                {
                    LastMsg = d;

                    var date = new Date();
                    var hour = date.getHours();
                    hour = (hour < 10 ? "0" : "") + hour;
                    var min  = date.getMinutes();
                    min = (min < 10 ? "0" : "") + min;
                    var yada = "[" + hour +":" + min + "] ";

                    var text = yada + util.format(d);

                    // Remove Color Codes from log
                    text = text.replace("\u001B[0m","");  // Reset
                    text = text.replace("\u001B[31m",""); // Red
                    text = text.replace("\u001B[32m",""); // Green
                    text = text.replace("\u001B[33m",""); // Yellow
                    text = text.replace("\u001B[34m",""); // Blue
                    text = text.replace("\u001B[35m",""); // Purple
                    text = text.replace("\u001B[36m",""); // Cyan

                    console_log.write(text + EOL);
                    process.stdout.write(yada +  util.format(d) + EOL);
                }
            };
            // this.onCommand = function(command) {
            //     console_log.write(">" + command + EOL);
            // };
        case 0:
            // Prevent crashes
            process.on('uncaughtException', function(err) {
                console.log(err.stack);
            });
        default:
            break;
    }*/
};

Log.prototype.onConnect = function(ip) {
    // Nothing
};

Log.prototype.onDisconnect = function(ip) {
    // Nothing
};

Log.prototype.onCommand = function(command) {
    // Nothing
}

Log.prototype.formatTime = function() {
    var date = new Date();

    var hour = date.getHours();
    hour = (hour < 10 ? "0" : "") + hour;

    var min  = date.getMinutes();
    min = (min < 10 ? "0" : "") + min;

    return hour + ":" + min;
}