node index.js
pause